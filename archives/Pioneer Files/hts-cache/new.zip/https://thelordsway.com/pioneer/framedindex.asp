
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Pioneer and Bell Church of Christ | Home</title>
<script type="text/javascript" src="https://www.thelordsway.com/sample/members/admin/scripts/FindTheTop.js"></script>
<link href="https://www.thelordsway.com/site14/default.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="https://www.thelordsway.com/sample/scripts/balloontip.css" />
<script type="text/javascript" src="https://www.thelordsway.com/sample/scripts/balloontip.js"></script>
<link href="https://www.thelordsway.com/p7exp/p7exp.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="https://www.thelordsway.com/p7exp/p7exp.js"></script>
<!--[if lte IE 7]>
<style>
#menuwrapper, #p7menubar ul a {height: 1%;}
a:active {width: auto;}
</style>
<![endif]-->
</head>
<body>
<!-- start header -->
<div id="header">
	
<div style="text-align: center; font-family: Arial;"><span style="font-size: 24pt;"><span style="font-size: 24pt; font-weight: bold; font-family: Garamond; font-style: italic;">Welcome to the</span><br />
		<span style="font-size: 24pt; font-weight: bold; font-family: Garamond; font-style: italic;">Pioneer and Bell Church of Christ</span></span></div>                                                                               
	<div id="menu">
		
<ul id="p7menubar">
	<li class="trigger"><a href="https://www.thelordsway.com/Pioneer/framedindex.asp?Group=Home">Home</a></li>
	
			<li><a href="https://www.thelordsway.com/Pioneer/framedindex.asp?Group=AboutUs">About Us</a>
				<ul>
					
								<li><a href="../site14/missions.asp?CongregationID=395&Group=AboutUs" title="Missions our congregation is involved with">Missions</a></li>
							
								<li><a href="../site14/purpose.asp?CongregationID=395&Group=AboutUs" title="Our purpose statement">Purpose</a></li>
							
								<li><a href="../site14/news.asp?CongregationID=395&Group=AboutUs" title="News and events">News</a></li>
							
								<li><a href="../site14/contacts.asp?CongregationID=395&Group=AboutUs" title="Contact Information">Contact Us</a></li>
							
								<li><a href="../site14/staff.asp?CongregationID=395&Group=AboutUs" title="Meet our staff">Staff</a></li>
							
							<li><a href="../site14/custom1.asp?CongregationID=395&Group=AboutUs">What Are the Churche</a></li>
						
							<li><a href="../site14/custom2.asp?CongregationID=395&Group=AboutUs">Article Index</a></li>
						
				</ul>
			</li>
			
			<li><a href="https://www.thelordsway.com/Pioneer/framedindex.asp?Group=Community">Community</a>
				<ul>
					
								<li><a href="../site14/discussion.asp?CongregationID=395&Group=Community" title="Discussion forum">Discussion</a></li>
							
								<li><a href="../site14/thoughts.asp?CongregationID=395&Group=Community" title="Sign our guestbook">Guest Book</a></li>
							
							<li><a href="../site14/custom1.asp?CongregationID=395&Group=Community">What Are the Churche</a></li>
						
							<li><a href="../site14/custom2.asp?CongregationID=395&Group=Community">Article Index</a></li>
						
				</ul>
			</li>
			
			<li><a href="https://www.thelordsway.com/Pioneer/framedindex.asp?Group=Events">Events</a>
				<ul>
					
							<li><a href="../site14/custom1.asp?CongregationID=395&Group=Events">What Are the Churche</a></li>
						
							<li><a href="../site14/custom2.asp?CongregationID=395&Group=Events">Article Index</a></li>
						
				</ul>
			</li>
			
			<li><a href="https://www.thelordsway.com/Pioneer/framedindex.asp?Group=Resources">Resources</a>
				<ul>
					
								<li><a href="../site14/articles.asp?CongregationID=395&Group=Resources" title="Articles ">Articles</a></li>
							
								<li><a href="../site14/doclib.asp?CongregationID=395&Group=Resources" title="Document Library">Documents</a></li>
							
							<li><a href="../site14/custom1.asp?CongregationID=395&Group=Resources">What Are the Churche</a></li>
						
							<li><a href="../site14/custom2.asp?CongregationID=395&Group=Resources">Article Index</a></li>
						
				</ul>
			</li>
			
		<li class="trigger"><a title="Members login" href="https://thelordsway.com/site14/members/members.asp?CongregationID=395">Members</a></li>
	
</ul>


	</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		
<form name="frmSearch" method="post" action="https://www.thelordsway.com/site14/search.asp?CongregationID=395">
<div style="float: right;">
	<b>Search:</b> <input type="text" name="Search" value="" size="20"><img onclick="document.frmSearch.submit();" src="../images/search.png">
</div>
</form><br>

	<br>

	<br><center><img style="margin: 0px; border-radius: 7px 7px 7px 7px; border: 7px solid rgb(255, 255, 255); box-shadow: 0pt 15px 10px -10px rgba(0, 0, 0, 0.5), 0pt 1px 4px rgba(0, 0, 0, 0.3);" src="/Pioneer/main.jpg"></center><br>


<center>
<style>
.MaxHght {
	max-height: 350px;
}
.MinHght {
	min-height: 370px;
}

</style>


</center>
<table width=100%>
	<tr>
		<td>
			<br>
			
<div><span style="font-family: 'Times New Roman'; font-size: 12pt;">Thank you for visiting our website. We have many study articles here that we hope will help you in learning more about God's word. Click the Resources button on the bar above. New articles are added monthly, come back and look for them.</span><span style="font-size: 16px; font-family: 'Times New Roman';">&nbsp;We offer Bible Study&nbsp;correspondence&nbsp;courses and tracts on several topics, just call us or send an email if you are interested, all at no charge. <span style="font-weight: bold;">We also have <span style="font-style: italic;">Let the Bible Speak Volumes 1 ,2 , 3 4 and 5</span>&nbsp;which contain our first 60 study ads. There is no charge for the books or shipping.</span></span></div>
<div><br />
	</div>
<div><br />
	</div>
<div><span style="font-family: 'Times New Roman'; font-size: 12pt; font-weight: bold;"><span style="font-style: italic; font-size: 14pt; ">If you are in our area, please join us for worship and Bible study classes.</span>&nbsp;</span><span style="font-family: 'Times New Roman';"><span style="font-size: 12pt;">&nbsp;</span><br />
		<span style="font-weight: bold;"><br />
			<br />
			</span><span style="font-size: 14pt;"><span style="font-weight: bold;">Visit our YouTube Channel at: (to get channel updates, be sure to click the 'Subscribe' button)</span><br />
			
			<p style=""><span style="font-size: 14pt; font-weight: bold;"><a href="https://www.youtube.com/@speakthetruth2608" style="">http://www.youtube.com/@TheKing4Life</a></span></p><br />
			</span><br />
		<br />
		</span></div>
<div><span style="font-size: 19px; font-family: 'Times New Roman';"><br />
		</span></div>
<div><span style="font-size: 19px; font-family: Garamond;"><br />
		</span></div>                                                                               
				<br><b>Address</b><br>
				900 N. Pioneer
						&nbsp;-&nbsp;<font size="2"><a target="_blank" href="http://www.mapquest.com/maps/map.adp?address=900+N.+Pioneer&city=Elk+City&state=OK&zipcode=73644">MapQuest</a></font><br>
					Elk City,&nbsp;OK
					&nbsp;73644<br>(580) 501-0175&nbsp;-&nbsp;Phone<br>N/A&nbsp;-&nbsp;Fax<br>
				
					<a href="../site14/sendmail.asp?CongregationID=395&Area=Master">Send us a message</a>&nbsp;-&nbsp;E-Mail<br>
				<br><b>Mailing Address</b><br>
				P O Box 821<br>Elk City, OK 73648<br>(580) 501-0175 - Phone<br>N/A - Fax<br>
			<br>
			<span style="font-family: 'Times New Roman'; font-size: 12pt;">Pioneer and Bell is on the west side of Elk City across from the High School. Take old Route 66 (Third) into Elk City, turn north at the stop light at Pioneer and Third (Route 66), go north about 4 blocks to Bell, our parking lot may also be entered from Pioneer a few yards north of our sign. We are located on the Northeast corner.</span>                                                                               
		</td>
	</tr>
</table>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
			
		<div id="news" class="boxed">
			<h2 class="title">Services</h2>
			<div class="content">
				
			<a onclick="FindTheTop();" href="../site14/servicedetail.asp?CongregationID=395&ServiceID=1248">Morning Worship</a><br>
		Sunday - 10:30 AM
			<hr style="border-style: solid; border-color: #C0C0C0;">
			<div style="clear: both;"></div>
		
			<a onclick="FindTheTop();" href="../site14/servicedetail.asp?CongregationID=395&ServiceID=1245">Evening Worship</a><br>
		Sunday - 6:00 PM
			<hr style="border-style: solid; border-color: #C0C0C0;">
			<div style="clear: both;"></div>
		
			<a onclick="FindTheTop();" href="../site14/servicedetail.asp?CongregationID=395&ServiceID=1243">Bible Class</a><br>
		Sunday - 9:30 AM
			<hr style="border-style: solid; border-color: #C0C0C0;">
			<div style="clear: both;"></div>
		
			<a onclick="FindTheTop();" href="../site14/servicedetail.asp?CongregationID=395&ServiceID=1246">Bible Class</a><br>
		Wednesday - 7:00 PM
			</div>
		</div>
	<br>
			
		<div id="news" class="boxed">
			<h2 class="title">News</h2>
			<div class="content">
				
			<u>5/27/2020</u><br>
			 New articles have been added, they are under the headings, "AMERICA'S PANTS ARE ON FIRE" and "WHAT GOD DO YOU SERVE?
		<a onclick="FindTheTop();" href="https://www.thelordsway.com/site14/newsdetail.asp?CongregationID=395&NewsID=6060&Return=indexbody.asp" style="text-decoration: none"><b>More>></b></a>
	
			<div style="clear: both;">&nbsp;</div>
		
			<hr style="border-style: solid; border-color: #C0C0C0;">
		
			<u>9/11/2019</u><br>
			We have added a page of titles of articles listed by topics.
		<a onclick="FindTheTop();" href="https://www.thelordsway.com/site14/newsdetail.asp?CongregationID=395&NewsID=6061&Return=indexbody.asp" style="text-decoration: none"><b>More>></b></a>
	
			<div style="clear: both;">&nbsp;</div>
		
			<hr style="border-style: solid; border-color: #C0C0C0;">
		
			<u>9/11/2019</u><br>
			We still have our "Let the Bible Speak" series, volumes one, two, three four, and five.
		<a onclick="FindTheTop();" href="https://www.thelordsway.com/site14/newsdetail.asp?CongregationID=395&NewsID=8222&Return=indexbody.asp" style="text-decoration: none"><b>More>></b></a>
	
			<div style="clear: both;">&nbsp;</div>
		
			</div>
		</div>
	<br>
			
		<div id="news" class="boxed">
			<h2 class="title">Staff</h2>
			<div class="content">
				
		<div>
		Patrick King<br>
		Preacher<br>
		<a onclick="FindTheTop();" href="../site14/staffbio.asp?StaffID=1607&CongregationID=395" style="text-decoration: none">More >></a>
		</div>
		<div style="clear: both;"></div>
		<hr style="border-style: solid; border-color: #C0C0C0;">
		
		<div>
		Luke Lewis<br>
		Preacher<br>
		<a onclick="FindTheTop();" href="../site14/staffbio.asp?StaffID=2635&CongregationID=395" style="text-decoration: none">More >></a>
		</div>
		<div style="clear: both;"></div>
		<hr style="border-style: solid; border-color: #C0C0C0;">
		
		<div>
		Earl Reed<br>
		Preacher<br>
		<a onclick="FindTheTop();" href="../site14/staffbio.asp?StaffID=2633&CongregationID=395" style="text-decoration: none">More >></a>
		</div>
		<div style="clear: both;"></div>
		<hr style="border-style: solid; border-color: #C0C0C0;">
		
		<div>
		Chris Thompson<br>
		Preacher<br>
		<a onclick="FindTheTop();" href="../site14/staffbio.asp?StaffID=2634&CongregationID=395" style="text-decoration: none">More >></a>
		</div>
		<div style="clear: both;"></div>
		<hr style="border-style: solid; border-color: #C0C0C0;">
		
			</div>
		</div>
	
		</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<center>
<!-- AddThis Button BEGIN -->
<div align="center" class="addthis_toolbox addthis_default_style addthis_32x32_style">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>
<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=clarkse"></script>
<!-- AddThis Button END -->
<b>Direct Page Link</b> <input style="background-color:rgba(0, 0, 0, 0.0); border-size: 0; border: 1px solid grey; border-radius: 4px;" type="text" name="CopyURL" size="100" value="https://www.thelordsway.com/pioneer/framedindex.asp?">
<table cellspacing="0" border="2">
	<tr>
		<td class="tdcenter" align=center style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-style: solid; border-top-width: 1px; border-bottom-style: none; border-bottom-width: medium"><b><font size=1><a style="text-decoration: none" class="poweredby" target="_parent" href="https://www.thelordsway.com">Powered By</a></font></b></td>
	</tr>
	<tr>
		<td class="tdcenter" align=center style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-style: none; border-top-width: medium; border-bottom-style: none; border-bottom-width: medium"><a class="menulink" target="_parent" href="https://www.thelordsway.com">
			<span style="text-decoration: overline"><u><font size="2" color="#339999">
			TheLordsWay.com</font></u></span></a></td>
	</tr>
	<tr>
		<td class="tdcenter" align=center style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-style: none; border-top-width: medium; border-bottom-style: solid; border-bottom-width: 1px"><font size=1><a style="text-decoration: none" class="poweredby" target="_parent" href="https://www.thelordsway.com">Click here to host your<br>own 
		church web site today!</a></font></td>
	</tr>

	
		<tr>
			<td align="center" style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-style: none; border-top-width: medium; border-bottom-style: solid; border-bottom-width: 1px"><center><b>&nbsp;<font size="2">You are visitor number</font>&nbsp;</b></center></td>
		</tr>
		<tr>
			<td align="center" style="border-left-style: solid; border-left-width: 1px; border-right-style: solid; border-right-width: 1px; border-top-style: none; border-top-width: medium; border-bottom-style: solid; border-bottom-width: 1px"><font face="Plump MT" color="#0000FF">
		    	<center>&nbsp;
				26086</font>&nbsp;
				</center>
			</td>
		</tr>
	
</table>
<a target="_blank" href="https://itunes.apple.com/us/app/thelordsway/id1202605793?ls=1&amp;mt=8"><img src="https://www.thelordsway.com/AppStoreBadge.png" width="135" /></a>&nbsp;
<a target="_blank" href="https://play.google.com/store/apps/details?id=thelordsway.android"><img src="https://www.thelordsway.com/googleplaybadge.png" width="135" /></a><br />
</center>

</div>
<!-- end footer -->
</body>
</html>
